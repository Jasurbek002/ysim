import{d as e,o as a,b as o,_ as s}from"./index-51e16f0c.js";const r=e({__name:"Objects",setup(t){return(_,c)=>(a(),o(s,{label:"INTELEKTUAL MULK OBYEKTLARI"}))}});export{r as default};
