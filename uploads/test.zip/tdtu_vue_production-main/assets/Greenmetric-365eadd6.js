import{d as e,o as i,b as a,w as n,_ as r,g as t,e as s}from"./index-51e16f0c.js";import{_ as o}from"./List.vue_vue_type_script_setup_true_lang-30091846.js";const l="/assets/green-78c18ce4.png",u=e({__name:"Greenmetric",setup(c){return(g,m)=>(i(),a(r,{label:"Greenmetric"},{default:n(()=>[t(o,{image:s(l),title:" Toshkent davlat texnika universiteti “Yashil reytingi “da",text:`Joriy yilning 12 – dekabrida “Greenmetric ning\r
                    jahon universitetlarining ekologiya va atrof-muhit barqarorligi boʻyicha\r
                    reytingini eʼlon qildi. Toshkent davlat texnika universiteti\r
                    ilk bor xalqaro yashil universitetlar reytingida\r
                    ishtirok etib “Greenmetric” reyting mezonlarida\r
                    quyidagi natijalarga erishildi:`,styles:"bg-grenn"},null,8,["image"])]),_:1}))}});export{u as default};
