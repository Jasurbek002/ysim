import{C as c,o as e,c as n}from"./index-51e16f0c.js";const o={};function r(t,s){return e(),n("div",null," doc ")}const _=c(o,[["render",r]]);export{_ as default};
