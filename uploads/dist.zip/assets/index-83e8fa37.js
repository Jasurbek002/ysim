import{s as i,j as o,g as n}from"./index-9e782184.js";const e=i.div`
  background-color: white;
  display: flex;
  border: 1px solid var(--border-color);
  border-radius: 12px;
  flex-direction: column;
  padding: 18px 14px;
  gap: 10px;
  box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.05);
`,t=i.div`
  color: var(--ussd-color);
  font-family: Roboto, sans-serif;
  font-size: 16px;
  font-style: normal;
  font-weight: 500;
  line-height: normal;
`,a=i.div`
  color: #333;
  font-family: Okta Neue, sans-serif;
  font-size: 16px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
`,l=i.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
`,d=({isFull:s,activate:r})=>o.jsxs(e,{children:[o.jsx(a,{children:s?"Xizmatni faollashtirish":" Xizmatni o'chirish"}),o.jsxs(l,{children:[o.jsx(t,{children:r}),o.jsx(n,{onClick:()=>window.navigator.clipboard.writeText(r)})]})]});export{d as C};
