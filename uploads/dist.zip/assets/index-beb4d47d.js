import{s as e,a,j as t,A as i}from"./index-9e782184.js";const r=e.div`
  max-width: 700px;
  min-width: 375px;
  height: 89px;
  background-color: var(--ussd-color);
  display: flex;
  padding: 0 16px 10px 16px;
  align-items: flex-end;
  justify-content: space-between;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  margin: 0 auto;
  z-index: 10;
`,x=e.p`
  font-family: Okta-Neue, sans-serif;
  font-size: 16px;
  color: var(--card-color);
  font-weight: 400;
  text-align: center;
  font-style: normal;
  line-height: normal;
`,c=o=>{const s=a(),n=()=>{s(-1)};return t.jsxs(r,{children:[t.jsx(i,{onClick:n}),t.jsx(x,{children:o.title}),t.jsx("div",{className:"w-[24px] h-[24px]"})]})};export{c as T};
