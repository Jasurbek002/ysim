import{s as t,j as e}from"./index-9e782184.js";const x=t.div`
  display: flex;
  align-items: start;
  flex-direction: column;
  background-color: var(--card-color);
  border-bottom: ${({$fullCard:r})=>!r&&"1px solid var(--border-color)"};
  border-radius: ${({$fullCard:r})=>r&&"12px"};
  border: ${({$fullCard:r})=>r&&"1px solid var(--border-color)"};
  gap: 8px;
  padding: ${({$fullCard:r})=>r?"24px 15px":"0 0 8px 0"};
  box-shadow: ${({$fullCard:r})=>r&&"0px 0px 20px 0px rgba(0, 0, 0, 0.07)"};
`,d=t.div`
  background-color: var(--card-color);
  padding: 24px 15px;
  border-radius: 12px;
  box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.07);
  display: flex;
  flex-direction: column;
  gap: 16px;
`,i=t.button`
  display: flex;
  padding: 15px 14px;
  justify-content: center;
  text-align: center;
  align-self: stretch;
  border-radius: 12px;
  background: rgba(0, 115, 255, 0.14);
  font-size: var(--text-size);
  color: var(--ussd-color);
  font-weight: 500;
`,n=({item:{package_name:r,price:o,deadline:a},fullCard:s})=>e.jsxs(x,{$fullCard:s,children:[e.jsx("div",{className:" text-[var(--ussd-color)] text-[20px] font-[550] ",children:r}),e.jsxs("div",{className:" flex justify-between w-full",children:[e.jsx("p",{className:"text-[12px] text-[var(--arrow-icon-color)]",children:"To'plam narxi"}),e.jsx("p",{className:"text-[var(--text-color)] text-[14px] font-[500]",children:o})]}),e.jsxs("div",{className:" flex justify-between w-full",children:[e.jsx("p",{className:"text-[12px] text-[var(--arrow-icon-color)] ",children:"Amal qilish muddati"}),e.jsx("p",{className:"font-[500] text-[14px]",children:a})]})]});export{d as C,n as I,i as M};
