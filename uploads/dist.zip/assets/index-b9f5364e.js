import{s as r,j as e,I as n,C as d,W as x,b as c}from"./index-9e782184.js";import{T as p}from"./index-beb4d47d.js";import{C as m}from"./index-83e8fa37.js";import f from"./index-7397008a.js";import"./motion-dc9e9ab1.js";const h=r.div`
  /* height: 261px; */
  display: flex;
  flex-direction: column;
  align-items: start;
  border: 1px;
  gap: 10px;
  border-radius: 12px;
  background-color: white;
  box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.07);
  padding: 14px 15px;
  border: 1px solid var(--border-color);
  background: var(--background-color);
`,o=r.p`
  color: var(--ussd-color);
  font-family: Okta-Neue, sans-serif;
  font-size: 20px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
`;o.Title=r.div`
  font-size: 15px;
  font-weight: 400;
  font-family: Okta Nueu, sans-serif;
  display: flex;
  justify-content: space-between;
  width: 100%;
  align-items: center;
`;const t=r.div`
  color: ${({$detail:s})=>s?"white":"var(--text-value-color)"};
  background-color: ${({$detail:s})=>s&&"var(--ussd-color)"};
  border-radius: ${({$detail:s})=>s&&"50px"};
  padding: ${({$detail:s})=>s&&"4px 10px"};
  font-family: Okta Neue, sans-serif;
  font-size: 14px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
`,j=r.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding: 10px 0;
  border-top: 1px solid var(--border-color);
  border-bottom: 1px solid var(--border-color);
`,u=({package_name:s,price:i,deadline:l,onclick:a})=>e.jsxs(h,{onClick:a,children:[e.jsx(o,{children:s}),e.jsxs(j,{children:[e.jsxs("div",{className:"flex items-center justify-between ",children:[e.jsxs("div",{className:"flex items-center ",children:[e.jsx("div",{className:"p-2  rounded-lg bg-[var(--border-color)] ",children:e.jsx(n,{})}),e.jsx("p",{className:"text-[#5A5A5A] ml-[10px] text-base",children:"Ajratilgan trafik"})]}),e.jsx(t,{children:s})]}),e.jsxs("div",{className:"flex items-center justify-between ",children:[e.jsxs("div",{className:"flex items-center ",children:[e.jsx("div",{className:"p-2  rounded-lg bg-[var(--border-color)] ",children:e.jsx(d,{})}),e.jsx("p",{className:"text-[#5A5A5A] ml-[10px] text-base",children:"Amal qilish muddati"})]}),e.jsx(t,{children:l})]})]}),e.jsxs(o.Title,{children:[e.jsxs("div",{className:"flex items-center ",children:[e.jsx("div",{className:"p-2  rounded-lg bg-[var(--border-color)] ",children:e.jsx(x,{})}),e.jsx("p",{className:"text-[#5A5A5A] ml-[10px] text-base",children:"Paket narxi"})]}),e.jsxs(t,{$detail:!0,children:[i," so'm/oy"]})]})]}),k=()=>{const[{packetsDetail:s}]=c();return e.jsxs(e.Fragment,{children:[e.jsx("div",{className:"h-[89px]"}),e.jsx(p,{title:"Internet paketlar"}),e.jsxs("div",{className:"flex flex-col p-4 gap-4",children:[e.jsx(u,{...s,detail:!0}),e.jsx(m,{activate:s==null?void 0:s.ussd_code}),e.jsx(f,{...s})]})]})};export{k as default};
