import{s as a,f as o,j as e}from"./index-9e782184.js";import{S as c}from"./ServiceCodes-d9ca787c.js";import{T as l}from"./index-beb4d47d.js";import{C as r}from"./index-83e8fa37.js";import x from"./index-7397008a.js";import"./motion-dc9e9ab1.js";const p=""+new URL("Frameservice-97e5e0cf.svg",import.meta.url).href,d=a.div`
 background: rgba(0, 115, 255, 0.14);
  display: flex;

  border: 1px solid red gap;
  /* margin-top: 16px; */
  margin: 16px 16px 16px 16px;
  /* position: fixed;
  bottom: 10px;
  left: 0; */
  border-radius: 12px;
  height: 55px;
  flex-direction: column;
  gap: 13px;
  padding-top: 15px;
  /* padding-left: 115px;
  padding-right: 115px; */
  color: white;
`,u=()=>{const{id:t}=o(),s=c.filter(i=>i.id.toString()===t);return e.jsxs("div",{children:[e.jsx(l,{title:s[0].title}),e.jsxs("div",{className:"pt-[89px] pb-[34px] px-4",children:[" ",e.jsxs("div",{className:"bg-[var(--background-color)] px-2 my-4  py-[14px] rounded-xl",children:[" ",e.jsx("h1",{className:"text-[var(--ussd-color)] pb-[10px] text-[20px] font-[500]",children:s[0].title}),e.jsx("p",{className:"text-[var(--arrow-icon-color)] ",children:s[0].text}),e.jsxs("div",{className:"flex items-center pt-[18px] ",children:[e.jsx("img",{src:p,alt:"",className:"bg-[var(--border-color)] p-1 rounded-lg"}),e.jsx("p",{className:"pl-2 text-[var(--icon-color)] ",children:"Xizmat narxi"})," ",e.jsx("p",{className:"bg-[var(--ussd-color)] ml-[120px] rounded-xl p-1  text-[14px] text-[var(--card-color)] text-center",children:s[0].price})]})]}),e.jsx(r,{activate:s[0].activate,isFull:!0}),e.jsxs("div",{className:"mt-2",children:[" ",e.jsx(r,{activate:s[0].unactivate,isFull:!1})]})]}),e.jsxs("div",{className:"px-4",children:[" ",e.jsx(x,{...s[0]})]}),e.jsxs("div",{className:" px-4",children:[" ",e.jsx(d,{children:e.jsx("button",{className:"text-[var(--ussd-color)]",children:"Paketni o'chirish"})})]})]})};export{u as default};
