import{s as l,j as e,I as x,P as p,M as m,W as h}from"./index-9e782184.js";const j=l.div`
  /* height: 261px; */
  display: flex;
  flex-direction: column;
  align-items: start;
  border: 1px;
  gap: 10px;
  border-radius: 12px;
  background-color: white;
  box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.07);
  padding: 14px 15px;
  border: 1px solid var(--border-color);
  background: var(--background-color);
`,t=l.p`
  color: var(--ussd-color);
  font-family: Okta-Neue, sans-serif;
  font-size: 20px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
`;t.Title=l.div`
  font-size: 15px;
  font-weight: 400;
  font-family: Okta Nueu, sans-serif;
  display: flex;
  justify-content: space-between;
  width: 100%;
  align-items: center;
`;const r=l.div`
  color: ${({$detail:s})=>s?"white":"var(--text-value-color)"};
  background-color: ${({$detail:s})=>s&&"var(--ussd-color)"};
  border-radius: ${({$detail:s})=>s&&"50px"};
  padding: ${({$detail:s})=>s&&"4px 10px"};
  font-family: Okta Neue, sans-serif;
  font-size: 14px;
  font-style: normal;
  font-weight: 400;
  line-height: normal;
`,f=l.div`
  width: 100%;
  display: flex;
  flex-direction: column;
  gap: 10px;
  padding: 10px 0;
  border-top: 1px solid var(--border-color);
  border-bottom: 1px solid var(--border-color);
`,v=({package_name:s,internet:o,price:i,minutes:a,sms:n,onclick:d,detail:c})=>e.jsxs(j,{onClick:d,children:[e.jsx(t,{children:s}),e.jsxs(f,{children:[e.jsxs("div",{className:"flex items-center justify-between ",children:[e.jsxs("div",{className:"flex items-center ",children:[e.jsx("div",{className:"p-2  rounded-lg bg-[var(--border-color)] ",children:e.jsx(x,{})}),e.jsx("p",{className:"text-[#5A5A5A] ml-[10px] text-base",children:"Internet"})]}),e.jsx(r,{children:o})]}),e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("div",{className:"flex items-center ",children:[e.jsx("div",{className:"p-2  rounded-lg bg-[var(--border-color)] ",children:e.jsx(p,{})}),e.jsx("p",{className:"text-[#5A5A5A] ml-[10px] text-base",children:"Daqiqalar"})]}),e.jsx(r,{children:a})]}),e.jsxs("div",{className:"flex items-center justify-between ",children:[e.jsxs("div",{className:"flex items-center",children:[e.jsx("div",{className:"p-2 rounded-lg bg-[var(--border-color)] ",children:e.jsx(m,{})}),e.jsx("p",{className:"text-[#5A5A5A] ml-[10px] text-base",children:"SMS"})]}),e.jsx(r,{children:n})]})]}),c?e.jsxs(t.Title,{children:[e.jsxs("div",{className:"flex items-center ",children:[e.jsx("div",{className:"p-2  rounded-lg bg-[var(--border-color)] ",children:e.jsx(h,{})}),e.jsx("p",{className:"text-[#5A5A5A] ml-[10px] text-base",children:"Oylik to'lov"})]}),e.jsxs(r,{$detail:!0,children:[i," so'm/oy"]})]}):e.jsxs(t.Title,{children:[e.jsx("p",{className:"text-[#858585]",children:"Abonent to'lovi"}),e.jsxs(r,{children:[i," so'm/oy"]})]})]});export{v as T};
