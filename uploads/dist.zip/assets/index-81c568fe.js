import{o as s,i as n,s as r,r as c,j as o}from"./index-9e782184.js";import{T as d}from"./index-beb4d47d.js";const l=""+new URL("email-eae33960.svg",import.meta.url).href,p=""+new URL("chatbot-8fac2b44.svg",import.meta.url).href,x=[{id:1,icon:s,ussdCode:"1099",description:"O'zbekiston ichidagi UZMOBILE abonentlari uchun"},{id:2,icon:s,ussdCode:"1155",description:"UZMOBILE korparativ abonentlari uchun"},{id:3,icon:s,ussdCode:" +99895 504 09 09",description:"Qolgan abonentlar uchun"},{id:4,icon:n,ussdCode:"https://uztelecom.uz/index.php/ru",description:"UZTELECOM web sahifasi"},{id:5,icon:l,ussdCode:"info@uztelecom.uz",description:"UZTELECOM elektron pochtasi"},{id:6,icon:p,ussdCode:"https://t.me/utc_uzbot",description:"Savol yo'llash uchun telegram-bot"}],u=r.div`
background-color: var(--background-color);
margin-top: 89px;
padding: 0 10px 0 10px;
`,h=r.div`
/* border: 1px solid var(--border-color); */
border-bottom: 1px solid var(--border-color);
border-top: 1px solid var(--border-color);
/* box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.05); */
/* margin: 5px auto; */
padding: 10px 10px 10px 10px;

`,C=()=>{const[t,m]=c.useState(!1),a=e=>{};return o.jsxs("div",{className:"h-[100vh] ",children:[o.jsx(d,{title:"Operator bilan aloqa"}),o.jsxs(u,{children:[o.jsx("p",{className:"text-center py-4 font-[600]",children:`"UZTELECOM" Qo'llab-quvvatlash markazi`}),x.map((e,i)=>o.jsxs(h,{className:"flex ",children:[o.jsxs("div",{className:"w-[30px] h-[40px]  mt-2 mr-1  flex items-center justify-center rounded-lg bg-[var(--border-color)] ",children:[" ",o.jsx("img",{src:e.icon,alt:"img",className:"w-[25px] h-[25px] text-[var(--icon-color)]"})]}),o.jsxs("div",{className:"flex flex-col px-[5px] ",onClick:()=>a(e.ussdCode),children:[t?o.jsx("a",{href:e.ussdCode,className:"text-[var(--ussd-color)] font-[600] pt-[5px]",children:e.ussdCode}):o.jsx("p",{className:"text-[var(--ussd-color)] font-[600] pt-[5px]",children:e.ussdCode}),o.jsx("p",{className:"text-[10px] py-[4px] text-[var(--item-color)] ",children:e.description})]})]},i))]})]})};export{C as default};
