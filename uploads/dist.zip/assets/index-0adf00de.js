import{s as o,j as i,u as l,c as s}from"./index-9e782184.js";import{T as d}from"./index-beb4d47d.js";const n=[{id:1,title:"Shaxsiy raqamingizni  tekshirish",code:"*100*4#"},{id:2,title:"Shaxsiy balansingizni tekshirish",code:"*100*5#"},{id:3,title:"Batafsil hisobot",code:"*100*2#"},{id:4,title:"4G  akitv qilish ",code:"*111*1*7*1#"},{id:5,title:"4G aktivatisiyadan o'chirish ",code:"*111*1*7*2#"},{id:6,title:"Sizga qo'g'iroq qilishdi xizmati ",code:"*111*2*4*1#"},{id:7,title:"Qulay almashinuv xizmati ",code:"*545#"},{id:8,title:"Qo'shimcha balans ",code:"*150#"},{id:9,title:"Pullik  hizmatlarni  o'chirish ",code:"*199#"},{id:10,title:"Menga  qong'iroq  qiling  xizmati",code:"*126#"}],r=[{id:1,title:"Balansni takshirish va tarif rejasi bo‘yicha to'plamlarni bilish",code:"*100#"},{id:2,title:"Navbatdagi abonent to'lovi belgilanish sanasini tekshirish",code:"*001#"},{id:3,title:"Barcha turdagi internet-to‘plamlar qoldig‘ini tekshirish",code:"*102#"},{id:4,title:"Daqiqalar to‘plamlarini tekshirish",code:"*103#"},{id:5,title:"SMS-to‘plamlarni tekshirish",code:"*104#"},{id:6,title:"Xizmatlarni yoqish va o‘chirish uchun mobil portal",code:"*111#"},{id:7,title:"Xizmat ko‘rsatish tili sifatida o‘zbek tilini tanlash",code:"*111*0*1#"},{id:8,title:"Xizmat ko‘rsatish tili sifatida rus tilini tanlash",code:"*111*0*2#"},{id:9,title:"Yoqilgan xizmatlarni bilish",code:"*140#"},{id:10,title:"O‘z raqamini bilish",code:"*150#"},{id:11,title:"Abonent nomiga qaysi raqamlar olinganini bilish",code:"*151#"},{id:12,title:"Mazkur oydagi harajatlarni bilish",code:"*111*025#"},{id:13,title:"“Sizga qo‘ng‘iroq qilishdi” xizmati holatini bilish",code:"*111*013#"},{id:14,title:" “Sizga qo‘ng‘iroq qilishdi” xizmatini yoqish",code:"*111*0131#"},{id:15,title:"“Sizga qo‘ng‘iroq qilishdi” xizmatini o‘chirish",code:"*111*0130#"},{id:16,title:" Menga qo‘ng‘iroq qiling” ",code:"*110#"},{id:17,title:"O‘z raqamini yashirish ",code:"*111*0101#"},{id:18,title:" O‘z raqamini ochish ",code:"*111*0100#"}],c=[{id:1,title:"Balansni tekshirish",code:"*100#"},{id:2,title:"USSD MENYU",code:"*111#"},{id:3,title:"Tarif Rejasini o'zgartirish",code:"*120#"},{id:4,title:"Restart ",code:"*111*1*7*1#"},{id:5,title:"Menga qo‘ng‘iroq qiling xizmati",code:"*125#"},{id:6,title:"SMS-to‘plamlar (50, 150, 500 SMS) ",code:"*147#"},{id:7,title:"Mening tarifim xizmati",code:"*200#"},{id:8,title:" Restart xizmati",code:"*222#"},{id:9,title:"Reklama SMSlaridan voz kechish",code:"*230#"},{id:10,title:"Telefonni IMEI kodini bilish",code:"*#06#"},{id:11,title:"Qo'shimcha internet-to‘plamlar",code:"*255#"},{id:12,title:'"SMS Avto-javob" xizmati',code:"*322#"},{id:13,title:'"Mening raqamlarim" xizmati',code:"*360#"},{id:14,title:'"Hisob kitob" xizmati',code:"*411#"},{id:15,title:'"Tunda 4Gni sinab ko‘ringr" xizmati',code:"*500#"},{id:16,title:'"Internet-avans" xizmati',code:"*515#"},{id:17,title:'"Yagona hisob" xizmati',code:"*900#"}],h=[{id:1,title:"Xizmatning yagona menyusi",code:"*111#"},{id:2,title:"Joriy tarif rejani bilish",code:"*110*05#"},{id:3,title:"Balans haqida ma’lumot;",code:"*102#"},{id:4,title:"daqiqalar qoldig’ini tekshirish ",code:"*106#"},{id:5,title:"SMSlar qoldig’ini tekshirish; ",code:"*105#"},{id:6,title:"Internet trafik qoldig’i haqida ma’lumot; ",code:"*103#"},{id:7,title:"Facebook, Telegram va WhatsApp  uchun megabayt ",code:"*109#"},{id:8,title:"Facebook, Odnoklassniki, Telegram va TAS-IX uchun megabayt  ",code:"*101#"},{id:9,title:"«Qayta ishga tushirish» xizmati  ",code:"*5#"},{id:10,title:"Abonent to’lovi yechilishi sanasini tekshirish ",code:"*202#"}],m=o.button`
display: flex;
padding: 18px 14px;
justify-content: space-between;
align-items: flex-start;
border-radius: 12px;
border: 1px solid var(--border-color);
background: var(--background-color);
box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.05);
`,g=o.p`

color: var(--text-color);
font-family: 'Roboto', sans-serif;;
font-size: var(--text-size);
font-style: normal;
font-weight: 800;
line-height: normal;
text-align:start;

`,x=o.p`
color: var(--ussd-color);
font-family: Roboto;
font-size: 14px;
font-style: normal;
font-weight: 600;
line-height: normal;    

`,b=({title:t,code:a,onclick:e})=>i.jsxs(m,{onClick:()=>e(a),children:[i.jsxs(g,{children:[t," "]})," ",i.jsx(x,{children:a})]}),p=()=>{const[t]=l(),a={uzmobile:n,beeline:h,ucell:c,mobiuz:r};return i.jsxs("div",{className:"bg-[var(--bg-color)]",children:[i.jsx("div",{className:"h-[89px]"}),i.jsx(d,{title:"USSD kodlar"}),i.jsx("div",{className:"w-[100%] overflow-y-auto gap-4 flex flex-col px-4 mt-4 pb-4",children:a[t==null?void 0:t.company].map(e=>i.jsx(b,{onclick:s,...e},e.id))})]})};export{p as default};
